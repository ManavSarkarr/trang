package com.example.TradingSystem.Model;

import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@Embeddable
public class Address {
@NotNull(message="The house number must be mentioned and it must be positive")
@Min(value =1)
	private int houseNo;
@NotBlank(message="Street name must be mentioned")
private String street;
@NotBlank(message="Nearest landmark must be mentioned")
private String landmark;
@NotBlank(message="Please mentioned the city name")
private String city;
@NotBlank(message="Please mention the state name")
private String state;
@NotNull(message="Please enter the pincode")
private int pincode;
public Address() {
	super();
	// TODO Auto-generated constructor stub
}
public Address(@NotNull(message = "The house number must be mentioned and it must be positive") @Min(1) int houseNo,
		@NotBlank(message = "Street name must be mentioned") String street,
		@NotBlank(message = "Nearest landmark must be mentioned") String landmark,
		@NotBlank(message = "Please mentioned the city name") String city,
		@NotBlank(message = "Please mention the state name") String state,
		@NotNull(message = "Please enter the pincode") int pincode) {
	super();
	this.houseNo = houseNo;
	this.street = street;
	this.landmark = landmark;
	this.city = city;
	this.state = state;
	this.pincode = pincode;
}
public int getHouseNo() {
	return houseNo;
}
public void setHouseNo(int houseNo) {
	this.houseNo = houseNo;
}
public String getStreet() {
	return street;
}
public void setStreet(String street) {
	this.street = street;
}
public String getLandmark() {
	return landmark;
}
public void setLandmark(String landmark) {
	this.landmark = landmark;
}
public String getCity() {
	return city;
}
public void setCity(String city) {
	this.city = city;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public int getPincode() {
	return pincode;
}
public void setPincode(int pincode) {
	this.pincode = pincode;
}
@Override
public String toString() {
	return "Address [houseNo=" + houseNo + ", street=" + street + ", landmark=" + landmark + ", city=" + city
			+ ", state=" + state + ", pincode=" + pincode + "]";
}


}
	
