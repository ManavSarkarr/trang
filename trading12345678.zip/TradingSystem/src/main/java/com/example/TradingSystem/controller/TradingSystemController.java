package com.example.TradingSystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.TradingSystem.Model.TradingSystem;
import com.example.TradingSystem.Service.TradingSystemService;
import com.example.TradingSystem.Service.TradingSystemServiceImpl;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/trading")
public class TradingSystemController {
	
@Autowired
TradingSystemServiceImpl tradingSystemServiceImpl;

@PostMapping("/create")
public ResponseEntity<TradingSystem> addCustomer(@RequestBody @Valid TradingSystem customer){
	TradingSystem system= tradingSystemServiceImpl.addCustomer(customer);
	return new ResponseEntity<>(system,HttpStatus.CREATED);
}
	@PutMapping("/update/{id}")
	public ResponseEntity<String> updateCustomersById(@PathVariable int id ,@RequestBody TradingSystem customer){
		tradingSystemServiceImpl.updateInformationById(id,customer);
		return ResponseEntity.status(HttpStatus.CREATED).body("Customer details updated successfully");
	}
	
	@GetMapping("/read/{id}")
	public ResponseEntity<TradingSystem> readCustomerInformationById(@PathVariable int id){
		TradingSystem readinformation=tradingSystemServiceImpl.readCustomerInformationById(id);
		return new ResponseEntity<>(readinformation,HttpStatus.OK);
	}
	
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteCustomerInformationById(@PathVariable int id){
		tradingSystemServiceImpl.deleteCustomerInformationById(id);
		return ResponseEntity.status(HttpStatus.ACCEPTED).body("Customer information deleted successfully");
	}

		
	}
