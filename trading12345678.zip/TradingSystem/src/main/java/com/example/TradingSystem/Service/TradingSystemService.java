package com.example.TradingSystem.Service;

import com.example.TradingSystem.Model.TradingSystem;

public interface TradingSystemService {
	
	public TradingSystem addCustomer(TradingSystem customer);
	
	public void updateInformationById(int id,TradingSystem customer);
	
	public void deleteCustomerInformationById(int id);
	
	public TradingSystem readCustomerInformationById(int id);
}
