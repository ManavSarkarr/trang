package com.example.TradingSystem.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.TradingSystem.Model.TradingSystem;

public interface TradingSystemRepository extends JpaRepository<TradingSystem,Integer> {

}
