package com.example.TradingSystem.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.TradingSystem.Exception.IdNotFoundException;
import com.example.TradingSystem.Model.TradingSystem;
import com.example.TradingSystem.Repository.TradingSystemRepository;
@Service
public class TradingSystemServiceImpl implements TradingSystemService  {

	@Autowired 
	TradingSystemRepository tradingSystemRepository;

	
	@Override
	public TradingSystem addCustomer(TradingSystem tradingSystem) {

	
		return tradingSystemRepository.save(tradingSystem);
	}
	
	@Override
	public  void updateInformationById(int id, TradingSystem tradingSystem) {
		
		TradingSystem  updateInformation= tradingSystemRepository.findById(id).orElseThrow(()-> new IdNotFoundException("Given Customer id" + id+"not found"));
		
		updateInformation.setCustomerName(tradingSystem.getCustomerName());
		updateInformation.setStockName(tradingSystem.getStockName());
		updateInformation.setStockQuantity(tradingSystem.getStockQuantity());
		updateInformation.setStopLossPrice(tradingSystem.getStopLossPrice());	
		updateInformation.setPanCard(tradingSystem.getPanCard());
		updateInformation.setAadhar(tradingSystem.getAadhar());
				tradingSystemRepository.save(updateInformation);
	}
	
	@Override
	public void deleteCustomerInformationById(int id) {
		
		TradingSystem deleteInformation = tradingSystemRepository.findById(id).orElseThrow(()->new IdNotFoundException("Given bike id: " +id+"not found and customer information are not deleted"));
		
		tradingSystemRepository.delete(deleteInformation);
	}
	
	@Override
	public TradingSystem readCustomerInformationById(int id) {
		return SystemRepository.findById(id).orElseThrow(()-> new IdNotFoundException("Given customer id: "+id+" not found"));
	}
}
	