package com.example.TradingSystem.Model;

import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.Valid;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

@Entity
@Table(name="Trading_System")
public class TradingSystem {
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int id;
	@NotBlank(message="please enter the customer name")
	@Size(max = 50, message = "Customer name must be less than 50 characters")
	private String customerName;
	@NotBlank(message="please provide stock name")
	//@Max(value=10,message="stock name should be at least 10 digits")
	private String stockName;
	@NotNull(message="please provide stock quantity")
	private int stockQuantity;
	@NotNull(message="provide proper stop loss price")
	private int stopLossPrice;
	@NotNull(message="please provide proper Bank account number")
	private int bankAccountNumber;
	@NotNull(message="provide proper trading acccount  number")
	private int tradingAccountNumber;
	@NotNull(message="provide proper pancard number")
	private int panCard;
	@NotNull(message="provide proper aadhar number")
	private int aadhar;
	@NotBlank(message="Notes is required")
	private String notes;
	@NotNull(message="provide proper phone number")
	private int phoneNumber;
	@Valid
	@Embedded
	private Address address;
	public TradingSystem() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TradingSystem(int id,
			@NotBlank(message = "please enter the customer name") @Size(max = 50, message = "Customer name must be less than 50 characters") String customerName,
			@NotBlank(message = "please provide stock name") String stockName,
			@NotNull(message = "please provide stock quantity") int stockQuantity,
			@NotNull(message = "provide proper stop loss price") int stopLossPrice,
			@NotNull(message = "please provide proper Bank account number") int bankAccountNumber,
			@NotNull(message = "provide proper trading acccount  number") int tradingAccountNumber,
			@NotNull(message = "provide proper pancard number") int panCard,
			@NotNull(message = "provide proper aadhar number") int aadhar,
			@NotBlank(message = "Notes is required") String notes,
			@NotNull(message = "provide proper phone number") int phoneNumber, @Valid Address address) {
		super();
		this.id = id;
		this.customerName = customerName;
		this.stockName = stockName;
		this.stockQuantity = stockQuantity;
		this.stopLossPrice = stopLossPrice;
		this.bankAccountNumber = bankAccountNumber;
		this.tradingAccountNumber = tradingAccountNumber;
		this.panCard = panCard;
		this.aadhar = aadhar;
		this.notes = notes;
		this.phoneNumber = phoneNumber;
		this.address = address;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getStockName() {
		return stockName;
	}
	public void setStockName(String stockName) {
		this.stockName = stockName;
	}
	public int getStockQuantity() {
		return stockQuantity;
	}
	public void setStockQuantity(int stockQuantity) {
		this.stockQuantity = stockQuantity;
	}
	public int getStopLossPrice() {
		return stopLossPrice;
	}
	public void setStopLossPrice(int stopLossPrice) {
		this.stopLossPrice = stopLossPrice;
	}
	public int getBankAccountNumber() {
		return bankAccountNumber;
	}
	public void setBankAccountNumber(int bankAccountNumber) {
		this.bankAccountNumber = bankAccountNumber;
	}
	public int getTradingAccountNumber() {
		return tradingAccountNumber;
	}
	public void setTradingAccountNumber(int tradingAccountNumber) {
		this.tradingAccountNumber = tradingAccountNumber;
	}
	public int getPanCard() {
		return panCard;
	}
	public void setPanCard(int panCard) {
		this.panCard = panCard;
	}
	public int getAadhar() {
		return aadhar;
	}
	public void setAadhar(int aadhar) {
		this.aadhar = aadhar;
	}
	public String getNotes() {
		return notes;
	}
	public void setNotes(String notes) {
		this.notes = notes;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "TradingSystem [id=" + id + ", customerName=" + customerName + ", stockName=" + stockName
				+ ", stockQuantity=" + stockQuantity + ", stopLossPrice=" + stopLossPrice + ", bankAccountNumber="
				+ bankAccountNumber + ", tradingAccountNumber=" + tradingAccountNumber + ", panCard=" + panCard
				+ ", aadhar=" + aadhar + ", notes=" + notes + ", phoneNumber=" + phoneNumber + ", address=" + address
				+ "]";
	}
}
	
	
	